var class_etat =
[
    [ "VAL", "class_etat.html#af3ddb2296ffc379b7f3ad2bf832f294e", [
      [ "VIDE", "class_etat.html#af3ddb2296ffc379b7f3ad2bf832f294ea4811ee91e77f4300db04a9451fd0e0f0", null ],
      [ "NOIR", "class_etat.html#af3ddb2296ffc379b7f3ad2bf832f294ea6e8dd9025eff15a0d6a71268d7e34632", null ],
      [ "BLANC", "class_etat.html#af3ddb2296ffc379b7f3ad2bf832f294ea386cdf6b926ee1da9e6469350d5928c8", null ],
      [ "KOWHITE", "class_etat.html#af3ddb2296ffc379b7f3ad2bf832f294ea9b3dd2418f67863f1da1da56f34fafff", null ],
      [ "KOBLACK", "class_etat.html#af3ddb2296ffc379b7f3ad2bf832f294ea14f75cb5bd86150422cbf856df2d1e92", null ],
      [ "NJ", "class_etat.html#af3ddb2296ffc379b7f3ad2bf832f294ea91e6e22a0ee67bc1371a024e1b2ded64", null ]
    ] ],
    [ "Etat", "class_etat.html#a44b4313a1a0bc0584a36be447802f2f4", null ],
    [ "Etat", "class_etat.html#a1e1232441c425f3f9adbf8cc99d9407e", null ],
    [ "Etat", "class_etat.html#a4e8da39ecb5b8edf66cc02addef85024", null ],
    [ "coord", "class_etat.html#a9aa2a1b7274bc6d8a66fbec9655e47d0", null ],
    [ "estVoisine", "class_etat.html#ab6e6b44dd68c041150332cee66dc74a3", null ],
    [ "getVal", "class_etat.html#ac0b81bbcf64cb3cc574e5a9dcdf94382", null ],
    [ "getX", "class_etat.html#aa25e66b110bc835523819392435e78c6", null ],
    [ "getY", "class_etat.html#a3e3e915f2261c83989a983e84b1273c1", null ],
    [ "isAStone", "class_etat.html#a98cc204acc13280c277e2aa6a32a54ec", null ],
    [ "isAStone", "class_etat.html#a64d8c0196e3e4de340726e2be29dec97", null ],
    [ "isPlayable", "class_etat.html#a2321679cabab0358adc8cf17dd119572", null ],
    [ "operator!=", "class_etat.html#a676159ce9be48a79d647f93cd9faee6e", null ],
    [ "operator=", "class_etat.html#ad400bb5d992ce25d27d56832fa0a9872", null ],
    [ "operator==", "class_etat.html#afa4f3f731268802b2a9c693cb738707b", null ],
    [ "setVal", "class_etat.html#aa88987ca54aee676717f05e4570c0aec", null ],
    [ "setX", "class_etat.html#ac020c4fe222274ac849a03fc8f19a99a", null ],
    [ "setY", "class_etat.html#a8a54fc9ecb1b97d84d2f1f259e3bf70e", null ]
];