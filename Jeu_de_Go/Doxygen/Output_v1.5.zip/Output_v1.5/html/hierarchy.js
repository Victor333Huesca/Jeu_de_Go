var hierarchy =
[
    [ "Arbre", "class_arbre.html", [
      [ "IA", "class_i_a.html", null ]
    ] ],
    [ "Clock", null, [
      [ "Timer", "class_timer.html", null ]
    ] ],
    [ "Drawable", null, [
      [ "Board", "class_board.html", null ],
      [ "Choice", "class_choice.html", [
        [ "Choice_miniature", "class_choice__miniature.html", null ],
        [ "Choice_Simple", "class_choice___simple.html", null ]
      ] ],
      [ "Infos", "class_infos.html", null ],
      [ "Screen", "class_screen.html", [
        [ "Game_window", "class_game__window.html", null ],
        [ "Menu", "class_menu.html", [
          [ "Menu_Miniature", "class_menu___miniature.html", null ],
          [ "Menu_simple", "class_menu__simple.html", null ]
        ] ]
      ] ],
      [ "Square", "class_square.html", null ]
    ] ],
    [ "Etat", "class_etat.html", null ],
    [ "Go_Solver", "class_go___solver.html", null ],
    [ "Goban", "class_goban.html", null ],
    [ "list", null, [
      [ "History", "class_history.html", null ]
    ] ],
    [ "Text", null, [
      [ "Timer", "class_timer.html", null ]
    ] ],
    [ "vector", null, [
      [ "Groupe", "class_groupe.html", null ]
    ] ]
];