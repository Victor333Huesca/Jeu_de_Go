var class_timer =
[
    [ "Timer", "class_timer.html#a5f16e8da27d2a5a5242dead46de05d97", null ],
    [ "Timer", "class_timer.html#a0a933922eec44419c94850e4e16f7121", null ],
    [ "~Timer", "class_timer.html#a14fa469c4c295c5fa6e66a4ad1092146", null ],
    [ "applyFont", "class_timer.html#a735fb44ab37e1fa12679d5ab291c488d", null ],
    [ "draw", "class_timer.html#a80c3f4ebbd84818de5531f5af3d511de", null ],
    [ "pause", "class_timer.html#a0289effad7b573c508bc27e405900a23", null ],
    [ "play", "class_timer.html#a84acbe09a8dddae46c997c57a70c5076", null ],
    [ "restart", "class_timer.html#aa3f7871196bb56202af2bc982bfbfff6", null ]
];