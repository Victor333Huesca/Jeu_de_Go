var class_go___solver =
[
    [ "Go_Solver", "class_go___solver.html#a30bd2f9d195a5553cc683f8314ea4b58", null ],
    [ "~Go_Solver", "class_go___solver.html#a63f22d429ea0e1c881d0b276edfe4b0e", null ],
    [ "getGoban", "class_go___solver.html#a95c1c268123a76b4f2db5b183bc721b6", null ],
    [ "getMusic", "class_go___solver.html#a321bc84b99b5ebdc2fbc59222aae8c74", null ],
    [ "getScreen", "class_go___solver.html#a40386a16847e889ffd280d5c6b993462", null ],
    [ "getScreens", "class_go___solver.html#aa86fa44c1be38ba004ff2f0475094cd1", null ],
    [ "launchTsumego", "class_go___solver.html#a6ca744f1f4586c3f90f2e47915034baf", null ],
    [ "loadMenu", "class_go___solver.html#a27ceb252dd57ac88d0dc2dbb04a25e32", null ],
    [ "Run", "class_go___solver.html#a84c021a62506ef8f5d43aae109298fe0", null ],
    [ "setGoban", "class_go___solver.html#a8452c66187c526e0a6051bbb42b9bbda", null ],
    [ "setMusic", "class_go___solver.html#a9b569ce8f1075a0c0136a46c62bd403a", null ],
    [ "setTarget", "class_go___solver.html#af792237fc55c0db4f5c5cc3299d51935", null ],
    [ "setTarget", "class_go___solver.html#ab2a2c57a24b076a6729e01504ef25377", null ],
    [ "turnMusicDown", "class_go___solver.html#a9bf8a0287fac1692ddf3b640ae1b04fe", null ],
    [ "turnMusicUp", "class_go___solver.html#a840b3c44ffd48baf0b7f2b4d15a831a0", null ],
    [ "turnSoundsDown", "class_go___solver.html#a1d7d0fad019f2d33caebb6cfe11d1f42", null ],
    [ "turnSoundsUp", "class_go___solver.html#a461b1fecf636b55d6b9f31b0035366c3", null ]
];