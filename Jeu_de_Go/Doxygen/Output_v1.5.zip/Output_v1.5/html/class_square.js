var class_square =
[
    [ "Value", "class_square.html#a7feeec236c037a9849114226adaa4ecc", [
      [ "Black", "class_square.html#a7feeec236c037a9849114226adaa4ecca936fd42872fc81c4f23c3aa55321a73d", null ],
      [ "White", "class_square.html#a7feeec236c037a9849114226adaa4ecca9eef9b633453678b028f5ea97a69ab32", null ],
      [ "None", "class_square.html#a7feeec236c037a9849114226adaa4ecca9b58b122a01aff177f48dc845711ffaf", null ]
    ] ],
    [ "Square", "class_square.html#a53fbf885454472fc818f541ecae5a80f", null ],
    [ "~Square", "class_square.html#a90af7ce1060cff7b717ceddb333846b8", null ],
    [ "draw", "class_square.html#a6665fa34ce5e672a880a253b1a21fb78", null ],
    [ "setPosition", "class_square.html#a9040f1ca39b88b8d9ac2a90648b1fb20", null ],
    [ "setValue", "class_square.html#a5fa0cbfce721c687308eec8e1a029d25", null ]
];