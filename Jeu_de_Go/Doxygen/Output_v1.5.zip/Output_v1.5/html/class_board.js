var class_board =
[
    [ "Board", "class_board.html#a9ee491d4fea680cf69b033374a9fdfcb", null ],
    [ "Board", "class_board.html#a3ab3bc5a15b6f8fb4aa8473fed2afdcb", null ],
    [ "Board", "class_board.html#abda1ce2449776e76715fc7b59c912935", null ],
    [ "~Board", "class_board.html#af73f45730119a1fd8f6670f53f959e68", null ],
    [ "cancel", "class_board.html#ac7ec911a62371650afd340d1535a1742", null ],
    [ "click", "class_board.html#a5fda73da080403d8a71a8593d581c350", null ],
    [ "draw", "class_board.html#a8c86104f9ff30a54cbd7520e006cd609", null ],
    [ "getGoban", "class_board.html#a19af96f42f5c38336010da2983abbf5c", null ],
    [ "getView", "class_board.html#ad3c413e185668418d3a16c1fec68e70d", null ],
    [ "getVolume", "class_board.html#a061962e73609a58802ad83674ec9b413", null ],
    [ "load", "class_board.html#a841a248dac4743611ba1825afd5d1297", null ],
    [ "load", "class_board.html#a3cea4df16e41c21666cf51789b7e9e78", null ],
    [ "setView", "class_board.html#afb8c7e3266134506f024b29e08fef695", null ],
    [ "setVolume", "class_board.html#a4450fe85fda29736cd835fed63d40a41", null ],
    [ "turnSoundsDown", "class_board.html#a648552cb139f9c0cc61f6372251739b2", null ],
    [ "turnSoundsUp", "class_board.html#a77d145afa8d71a85c4097aca08c30525", null ],
    [ "zoom", "class_board.html#a0b098808fd9214c752097a623a7c717e", null ]
];