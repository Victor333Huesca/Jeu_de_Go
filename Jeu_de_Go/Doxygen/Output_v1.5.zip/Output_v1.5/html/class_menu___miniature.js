var class_menu___miniature =
[
    [ "Menu_Miniature", "class_menu___miniature.html#a9bc0436adab538cddc4074003d324a82", null ],
    [ "~Menu_Miniature", "class_menu___miniature.html#a6893bda2d8bc8f29ac0646e976082515", null ],
    [ "setItemsTextures", "class_menu___miniature.html#afad04c066c7e436bbf9cccde310d07dc", null ]
];