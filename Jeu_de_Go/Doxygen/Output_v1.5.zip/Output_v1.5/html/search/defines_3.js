var searchData=
[
  ['infos_5fimg_5fsize_5fx',['INFOS_IMG_SIZE_X',['../_globals_8h.html#a45d58a203775276414590e88075b3df1',1,'Globals.h']]],
  ['infos_5fimg_5fsize_5fy',['INFOS_IMG_SIZE_Y',['../_globals_8h.html#a3c0fc2f4f7cbb338b08710ca303bf76a',1,'Globals.h']]],
  ['infos_5fsize',['INFOS_SIZE',['../_globals_8h.html#ae718f57a42ce5ec43e2c9b796ae274a3',1,'Globals.h']]],
  ['infos_5ftimer_5fpos_5fblack',['INFOS_TIMER_POS_BLACK',['../_globals_8h.html#a24e01f9a0d124dc892c2005522137919',1,'Globals.h']]],
  ['infos_5ftimer_5fpos_5fwhite',['INFOS_TIMER_POS_WHITE',['../_globals_8h.html#ab4d627867dc917bba00dca2f29b2d71f',1,'Globals.h']]],
  ['infos_5ftimer_5fsize',['INFOS_TIMER_SIZE',['../_globals_8h.html#a43b41a9de524f0a1513a9975edec6d35',1,'Globals.h']]],
  ['infos_5fturn_5fpos',['INFOS_TURN_POS',['../_globals_8h.html#a03d1bfdbdc4269467186d881d57c481c',1,'Globals.h']]],
  ['infos_5fturn_5fsize',['INFOS_TURN_SIZE',['../_globals_8h.html#a71a3db3491400069b81c38becdb73e31',1,'Globals.h']]]
];
