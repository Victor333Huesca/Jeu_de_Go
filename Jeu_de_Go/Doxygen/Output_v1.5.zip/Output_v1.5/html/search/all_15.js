var searchData=
[
  ['warning',['warning',['../class_i_a.html#a7099f0c1f9a2c0c598975ac0ff6a32bc',1,'IA']]],
  ['white',['White',['../class_square.html#a7feeec236c037a9849114226adaa4ecca9eef9b633453678b028f5ea97a69ab32',1,'Square']]],
  ['window_5fheight',['WINDOW_HEIGHT',['../_globals_8h.html#a5473cf64fa979b48335079c99532e243',1,'Globals.h']]],
  ['window_5fwidth',['WINDOW_WIDTH',['../_globals_8h.html#a498d9f026138406895e9a34b504ac6a6',1,'Globals.h']]],
  ['windows_2eh',['Windows.h',['../_windows_8h.html',1,'']]]
];
