var searchData=
[
  ['main',['main',['../_main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'Main.cpp']]],
  ['menu',['Menu',['../class_menu.html#a0e8556179fdcc650e7f3aa58b05f9f4f',1,'Menu']]],
  ['menu_5fminiature',['Menu_Miniature',['../class_menu___miniature.html#a9bc0436adab538cddc4074003d324a82',1,'Menu_Miniature']]],
  ['menu_5fsimple',['Menu_simple',['../class_menu__simple.html#aa85e31333052b51c3d138ec0689630c2',1,'Menu_simple']]],
  ['move',['move',['../class_goban.html#a7dd1a7b53322bde2a831a923059e43a3',1,'Goban']]]
];
