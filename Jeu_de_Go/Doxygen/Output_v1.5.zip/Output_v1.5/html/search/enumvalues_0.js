var searchData=
[
  ['audio',['AUDIO',['../_globals_8h.html#a3d5776bab98402b03be09156bacf4f68ad45d481f1c1a6029ce6a398e52e53bfd',1,'Globals.h']]]
];
