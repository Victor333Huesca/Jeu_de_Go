var searchData=
[
  ['choices',['choices',['../class_menu.html#aa40e2b74e7bdeee960889e083eca15d2',1,'Menu']]],
  ['cur_5fchoice',['cur_choice',['../class_menu.html#a91fc2547256d492def0845bd1ebcfaf8',1,'Menu']]]
];
