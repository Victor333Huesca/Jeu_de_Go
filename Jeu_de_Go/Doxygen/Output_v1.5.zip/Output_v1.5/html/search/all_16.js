var searchData=
[
  ['zoom',['zoom',['../class_board.html#a0b098808fd9214c752097a623a7c717e',1,'Board::zoom()'],['../class_game__window.html#a9b9b15469cb0ced1a22f28e447983b56',1,'Game_window::zoom()']]],
  ['zoom_5ffactor',['ZOOM_FACTOR',['../_board_8h.html#a2a3b4f0d88b092d0f370a8ac7db93521',1,'Board.h']]]
];
