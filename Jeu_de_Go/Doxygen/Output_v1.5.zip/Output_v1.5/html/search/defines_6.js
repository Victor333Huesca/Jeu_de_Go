var searchData=
[
  ['offset_5fx_5fb',['OFFSET_X_B',['../_globals_8h.html#a0f1acf36ad24a8dc102d4852f749b05d',1,'Globals.h']]],
  ['offset_5fx_5fe',['OFFSET_X_E',['../_globals_8h.html#a7153afbafe1a71c480362c7e58307732',1,'Globals.h']]],
  ['offset_5fy_5fb',['OFFSET_Y_B',['../_globals_8h.html#a983853d8323b5d5022a9ba4dbb1c1a52',1,'Globals.h']]],
  ['offset_5fy_5fe',['OFFSET_Y_E',['../_globals_8h.html#a70de4b209ed9e04a89f6718565e5df9b',1,'Globals.h']]]
];
