var searchData=
[
  ['zoom_5ffactor',['ZOOM_FACTOR',['../_board_8h.html#a2a3b4f0d88b092d0f370a8ac7db93521',1,'Board.h']]]
];
