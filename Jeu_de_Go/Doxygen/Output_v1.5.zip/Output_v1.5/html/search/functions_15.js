var searchData=
[
  ['zoom',['zoom',['../class_board.html#a0b098808fd9214c752097a623a7c717e',1,'Board::zoom()'],['../class_game__window.html#a9b9b15469cb0ced1a22f28e447983b56',1,'Game_window::zoom()']]]
];
