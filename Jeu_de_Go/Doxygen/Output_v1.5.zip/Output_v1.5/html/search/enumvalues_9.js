var searchData=
[
  ['pause',['PAUSE',['../_globals_8h.html#a3d5776bab98402b03be09156bacf4f68a56b36d0d0bb01b339cf1041adc08e262',1,'Globals.h']]],
  ['piste_5f1',['PISTE_1',['../_globals_8h.html#ad531d267a0e8da4d0683298e06912177ae32bc6a795a964c2b3bd2d85b931e2eb',1,'Globals.h']]],
  ['previous',['PREVIOUS',['../_globals_8h.html#a3d5776bab98402b03be09156bacf4f68ad9600a436d5cc272dfd53f6c45fdeca4',1,'Globals.h']]],
  ['problems_5fmenu',['PROBLEMS_MENU',['../_globals_8h.html#a3d5776bab98402b03be09156bacf4f68a774064583e32bd7eaaf1590b91e0000a',1,'Globals.h']]]
];
