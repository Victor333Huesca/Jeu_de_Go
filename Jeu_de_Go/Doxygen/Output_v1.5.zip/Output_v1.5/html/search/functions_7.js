var searchData=
[
  ['history',['History',['../class_history.html#afba1384643f419d079e78adb1497f741',1,'History']]]
];
