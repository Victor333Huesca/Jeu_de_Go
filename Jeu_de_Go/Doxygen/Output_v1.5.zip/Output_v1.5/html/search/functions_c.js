var searchData=
[
  ['next',['next',['../class_history.html#ab0535cf179200bf8a79a854aac783aa1',1,'History']]]
];
