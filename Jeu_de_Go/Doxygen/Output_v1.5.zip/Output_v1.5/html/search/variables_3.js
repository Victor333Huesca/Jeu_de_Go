var searchData=
[
  ['tgoban',['TGOBAN',['../_goban_8h.html#a8fb0ca5d8c4020b0a59e2b27b4780c99',1,'Goban.h']]]
];
