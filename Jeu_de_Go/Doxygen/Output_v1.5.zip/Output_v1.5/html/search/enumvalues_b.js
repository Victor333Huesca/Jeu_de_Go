var searchData=
[
  ['white',['White',['../class_square.html#a7feeec236c037a9849114226adaa4ecca9eef9b633453678b028f5ea97a69ab32',1,'Square']]]
];
