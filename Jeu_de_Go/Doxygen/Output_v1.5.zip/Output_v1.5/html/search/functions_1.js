var searchData=
[
  ['board',['Board',['../class_board.html#a9ee491d4fea680cf69b033374a9fdfcb',1,'Board::Board()'],['../class_board.html#a3ab3bc5a15b6f8fb4aa8473fed2afdcb',1,'Board::Board(const sf::Vector2&lt; T &gt; &amp;_size)'],['../class_board.html#abda1ce2449776e76715fc7b59c912935',1,'Board::Board(const T &amp;x, const T &amp;y)']]]
];
