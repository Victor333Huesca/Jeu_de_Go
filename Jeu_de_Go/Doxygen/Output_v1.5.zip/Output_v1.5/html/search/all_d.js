var searchData=
[
  ['nb_5fsquares_5fx',['NB_SQUARES_X',['../_globals_8h.html#a82f6b8e39a8581556115a00e1f1fe640',1,'Globals.h']]],
  ['nb_5fsquares_5fy',['NB_SQUARES_Y',['../_globals_8h.html#a9fd68c9fa6812dc5f323c2e8d369a208',1,'Globals.h']]],
  ['next',['next',['../class_history.html#ab0535cf179200bf8a79a854aac783aa1',1,'History']]],
  ['nj',['NJ',['../class_etat.html#af3ddb2296ffc379b7f3ad2bf832f294ea91e6e22a0ee67bc1371a024e1b2ded64',1,'Etat']]],
  ['no_5fchange',['NO_CHANGE',['../_globals_8h.html#a3d5776bab98402b03be09156bacf4f68a7fb0c1cca10ff57ae7aa3878ba530fbd',1,'Globals.h']]],
  ['noir',['NOIR',['../class_etat.html#af3ddb2296ffc379b7f3ad2bf832f294ea6e8dd9025eff15a0d6a71268d7e34632',1,'Etat']]],
  ['none',['None',['../class_square.html#a7feeec236c037a9849114226adaa4ecca9b58b122a01aff177f48dc845711ffaf',1,'Square']]]
];
