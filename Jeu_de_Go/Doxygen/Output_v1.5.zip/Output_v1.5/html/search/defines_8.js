var searchData=
[
  ['view_5fboard_5fpos_5fx',['VIEW_BOARD_POS_X',['../_globals_8h.html#a35c37fbd7440b99d6b94ce57e56e400d',1,'Globals.h']]],
  ['view_5fboard_5fpos_5fy',['VIEW_BOARD_POS_Y',['../_globals_8h.html#ad4c170b00098f64eb63bfcc15481d589',1,'Globals.h']]],
  ['view_5finfos_5fpos_5fx',['VIEW_INFOS_POS_X',['../_globals_8h.html#acebc314888ffa193c58ffc7ab7e51577',1,'Globals.h']]],
  ['view_5finfos_5fpos_5fy',['VIEW_INFOS_POS_Y',['../_globals_8h.html#ad31629854cd0f3734ec5484005abc5e1',1,'Globals.h']]]
];
