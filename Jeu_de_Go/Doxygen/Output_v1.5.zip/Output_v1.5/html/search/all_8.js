var searchData=
[
  ['history',['History',['../class_history.html',1,'History'],['../class_history.html#afba1384643f419d079e78adb1497f741',1,'History::History()']]],
  ['history_2ecpp',['History.cpp',['../_history_8cpp.html',1,'']]],
  ['history_2eh',['History.h',['../_history_8h.html',1,'']]]
];
