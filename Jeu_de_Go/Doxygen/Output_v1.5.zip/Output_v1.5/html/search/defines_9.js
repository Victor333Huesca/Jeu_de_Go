var searchData=
[
  ['window_5fheight',['WINDOW_HEIGHT',['../_globals_8h.html#a5473cf64fa979b48335079c99532e243',1,'Globals.h']]],
  ['window_5fwidth',['WINDOW_WIDTH',['../_globals_8h.html#a498d9f026138406895e9a34b504ac6a6',1,'Globals.h']]]
];
