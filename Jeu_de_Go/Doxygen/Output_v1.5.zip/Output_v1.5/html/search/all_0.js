var searchData=
[
  ['_5f_5ferror_5flevel_5f_5f',['__ERROR_LEVEL__',['../_globals_8h.html#a4748dfe6071af5d830ff6b7a6c8f3990',1,'Globals.h']]],
  ['_5finc_5fwindows',['_INC_WINDOWS',['../_windows_8h.html#a62c692e3e6314806b9d12f6f3a7113df',1,'Windows.h']]]
];
