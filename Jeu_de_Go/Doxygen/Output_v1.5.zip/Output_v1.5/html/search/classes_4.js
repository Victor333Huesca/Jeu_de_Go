var searchData=
[
  ['game_5fwindow',['Game_window',['../class_game__window.html',1,'']]],
  ['go_5fsolver',['Go_Solver',['../class_go___solver.html',1,'']]],
  ['goban',['Goban',['../class_goban.html',1,'']]],
  ['groupe',['Groupe',['../class_groupe.html',1,'']]]
];
