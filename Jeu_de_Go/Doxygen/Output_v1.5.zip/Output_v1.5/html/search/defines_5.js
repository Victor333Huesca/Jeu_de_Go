var searchData=
[
  ['nb_5fsquares_5fx',['NB_SQUARES_X',['../_globals_8h.html#a82f6b8e39a8581556115a00e1f1fe640',1,'Globals.h']]],
  ['nb_5fsquares_5fy',['NB_SQUARES_Y',['../_globals_8h.html#a9fd68c9fa6812dc5f323c2e8d369a208',1,'Globals.h']]]
];
