var searchData=
[
  ['log_5ffile',['log_file',['../_globals_8h.html#a0a56d03a6eba05895e878d162ab044c6',1,'Globals.h']]]
];
