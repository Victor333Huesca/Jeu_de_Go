var searchData=
[
  ['board_5fheight',['BOARD_HEIGHT',['../_globals_8h.html#a94ed08e31d2f3a38d35f0cb89c762f04',1,'Globals.h']]],
  ['board_5fwidth',['BOARD_WIDTH',['../_globals_8h.html#a1cd139e8d1f7ae83f54c8d477313d8ea',1,'Globals.h']]]
];
