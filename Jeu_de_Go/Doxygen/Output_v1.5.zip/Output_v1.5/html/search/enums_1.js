var searchData=
[
  ['screens',['Screens',['../_globals_8h.html#a3d5776bab98402b03be09156bacf4f68',1,'Globals.h']]]
];
