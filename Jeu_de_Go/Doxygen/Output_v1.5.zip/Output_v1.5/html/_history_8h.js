var _history_8h =
[
    [ "History", "class_history.html", "class_history" ],
    [ "operator<<", "_history_8h.html#aeed6b538504591f022c44a6bcf42aafc", null ]
];