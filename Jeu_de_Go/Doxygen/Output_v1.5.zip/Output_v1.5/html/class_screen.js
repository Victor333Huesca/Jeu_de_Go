var class_screen =
[
    [ "draw", "class_screen.html#abcb5544dfe717c7da181520803f43e25", null ],
    [ "Run", "class_screen.html#abbb6a9b3d8fdc44620080e54d090e8c7", null ]
];