var _history_8cpp =
[
    [ "operator<<", "_history_8cpp.html#aeed6b538504591f022c44a6bcf42aafc", null ]
];