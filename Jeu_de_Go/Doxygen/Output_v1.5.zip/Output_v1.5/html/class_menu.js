var class_menu =
[
    [ "Menu", "class_menu.html#a0e8556179fdcc650e7f3aa58b05f9f4f", null ],
    [ "~Menu", "class_menu.html#a831387f51358cfb88cd018e1777bc980", null ],
    [ "addItem", "class_menu.html#aa8032782ee75fba5fa17bf7a20635c68", null ],
    [ "draw", "class_menu.html#a7bc75c51f0ae43faeb694b8a0c4c7d16", null ],
    [ "getPosition", "class_menu.html#a589f53bbd6436b381b5ec92a609d5d66", null ],
    [ "getSize", "class_menu.html#ad99768326c994acf4fba6d9df60d1bcc", null ],
    [ "Run", "class_menu.html#ac72037385d58cb1c814d7702c79e93f5", null ],
    [ "setPrevious", "class_menu.html#ab2b8f2fc48dfbf397a81e9a1b638f970", null ],
    [ "showAdresses", "class_menu.html#ac4cf83e0769be3a20583668f210d98ef", null ],
    [ "choices", "class_menu.html#aa40e2b74e7bdeee960889e083eca15d2", null ],
    [ "cur_choice", "class_menu.html#a91fc2547256d492def0845bd1ebcfaf8", null ]
];