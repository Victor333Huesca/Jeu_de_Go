var class_choice___simple =
[
    [ "Choice_Simple", "class_choice___simple.html#aba8dc060adb5b2f393bbfb3d09127761", null ],
    [ "Choice_Simple", "class_choice___simple.html#a00412cfa29b144f0aca041b93fab4b26", null ],
    [ "~Choice_Simple", "class_choice___simple.html#a6d5b3fe8aa2969f8eaffa4e5fd3b47d9", null ],
    [ "draw", "class_choice___simple.html#ae8f4cedc34a10d3c35efce8cec1bec54", null ],
    [ "setFont", "class_choice___simple.html#a035e32f90e4561b666b6571bce06e207", null ]
];