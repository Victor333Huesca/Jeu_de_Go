var class_menu__simple =
[
    [ "Menu_simple", "class_menu__simple.html#aa85e31333052b51c3d138ec0689630c2", null ],
    [ "~Menu_simple", "class_menu__simple.html#a82cb459eae7f0c28d2576ead6430fe52", null ],
    [ "addItem", "class_menu__simple.html#a0fc5b4ec10c844f34495364f70cd333e", null ],
    [ "setItemsFonts", "class_menu__simple.html#a1273e6743ee892cd8651968efd595b73", null ],
    [ "setItemsTextures", "class_menu__simple.html#a4717470decb5666cbac7aa879aade5fa", null ]
];