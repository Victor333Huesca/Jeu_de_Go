var class_infos =
[
    [ "Infos", "class_infos.html#a0032935a2fbfcd006ffd71d90a74c4cf", null ],
    [ "~Infos", "class_infos.html#a98973ef2400dabed724a65e1fe319f46", null ],
    [ "draw", "class_infos.html#af7a440e4bc838e7b3251cbd20c7ad0ae", null ],
    [ "getView", "class_infos.html#af68a0d5dafcc767ae4b2b46ac8d7fbe2", null ],
    [ "setCurPlayer", "class_infos.html#a5dee8a8817c307c570db905429480d79", null ]
];