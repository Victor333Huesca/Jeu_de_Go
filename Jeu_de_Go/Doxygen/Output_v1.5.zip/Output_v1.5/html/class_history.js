var class_history =
[
    [ "History", "class_history.html#afba1384643f419d079e78adb1497f741", null ],
    [ "~History", "class_history.html#a5b00b64a1ddee04e60d5a3b517fd6d4c", null ],
    [ "add", "class_history.html#a90222df7f73ae9cfda56bdb66cb1985e", null ],
    [ "cancel", "class_history.html#a6e1bcaa1d3ecc646131e6f73a2544f35", null ],
    [ "clear", "class_history.html#a8ef13fdf00ec0786268fd6bd211bf38f", null ],
    [ "current", "class_history.html#a0ca66ba5a026689877e027754fc5bd52", null ],
    [ "display", "class_history.html#a5c1724d84912d1571d2475b2fb703081", null ],
    [ "next", "class_history.html#ab0535cf179200bf8a79a854aac783aa1", null ],
    [ "previous", "class_history.html#a8a0bb0748169bc93404987108a14f4bc", null ]
];