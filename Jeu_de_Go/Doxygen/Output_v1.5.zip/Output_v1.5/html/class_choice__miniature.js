var class_choice__miniature =
[
    [ "Choice_miniature", "class_choice__miniature.html#a156cdcafd4f44bdcf262669612fa8b82", null ],
    [ "Choice_miniature", "class_choice__miniature.html#a0eee4352ef523c2d640a847ad016295d", null ],
    [ "~Choice_miniature", "class_choice__miniature.html#aa04b8d4c3ad3e99efad7ffe433d96fbe", null ],
    [ "showAdressTextures", "class_choice__miniature.html#a6f413024d98b0c334c5a3e6ec87eba9b", null ]
];