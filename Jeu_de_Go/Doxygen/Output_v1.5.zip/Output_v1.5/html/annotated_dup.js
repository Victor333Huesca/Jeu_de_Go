var annotated_dup =
[
    [ "Arbre", "class_arbre.html", "class_arbre" ],
    [ "Board", "class_board.html", "class_board" ],
    [ "Choice", "class_choice.html", "class_choice" ],
    [ "Choice_miniature", "class_choice__miniature.html", "class_choice__miniature" ],
    [ "Choice_Simple", "class_choice___simple.html", "class_choice___simple" ],
    [ "Etat", "class_etat.html", "class_etat" ],
    [ "Game_window", "class_game__window.html", "class_game__window" ],
    [ "Go_Solver", "class_go___solver.html", "class_go___solver" ],
    [ "Goban", "class_goban.html", "class_goban" ],
    [ "Groupe", "class_groupe.html", "class_groupe" ],
    [ "History", "class_history.html", "class_history" ],
    [ "IA", "class_i_a.html", null ],
    [ "Infos", "class_infos.html", "class_infos" ],
    [ "Menu", "class_menu.html", "class_menu" ],
    [ "Menu_Miniature", "class_menu___miniature.html", "class_menu___miniature" ],
    [ "Menu_simple", "class_menu__simple.html", "class_menu__simple" ],
    [ "Screen", "class_screen.html", "class_screen" ],
    [ "Square", "class_square.html", "class_square" ],
    [ "Timer", "class_timer.html", "class_timer" ]
];