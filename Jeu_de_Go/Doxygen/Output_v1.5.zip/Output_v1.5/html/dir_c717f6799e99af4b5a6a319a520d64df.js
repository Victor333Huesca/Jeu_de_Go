var dir_c717f6799e99af4b5a6a319a520d64df =
[
    [ "Game", "dir_aba294cfc96023bce0e68c14296e19fd.html", "dir_aba294cfc96023bce0e68c14296e19fd" ],
    [ "Choice.cpp", "_choice_8cpp.html", null ],
    [ "Choice.h", "_choice_8h.html", [
      [ "Choice", "class_choice.html", "class_choice" ]
    ] ],
    [ "Choice_miniature.cpp", "_choice__miniature_8cpp.html", null ],
    [ "Choice_miniature.h", "_choice__miniature_8h.html", [
      [ "Choice_miniature", "class_choice__miniature.html", "class_choice__miniature" ]
    ] ],
    [ "Choice_Simple.cpp", "_choice___simple_8cpp.html", null ],
    [ "Choice_Simple.h", "_choice___simple_8h.html", [
      [ "Choice_Simple", "class_choice___simple.html", "class_choice___simple" ]
    ] ],
    [ "Globals.h", "_globals_8h.html", "_globals_8h" ],
    [ "Go_Solver.cpp", "_go___solver_8cpp.html", null ],
    [ "Go_Solver.h", "_go___solver_8h.html", [
      [ "Go_Solver", "class_go___solver.html", "class_go___solver" ]
    ] ],
    [ "Main.cpp", "_main_8cpp.html", "_main_8cpp" ],
    [ "Menu.cpp", "_menu_8cpp.html", null ],
    [ "Menu.h", "_menu_8h.html", [
      [ "Menu", "class_menu.html", "class_menu" ]
    ] ],
    [ "Menu_Miniature.cpp", "_menu___miniature_8cpp.html", null ],
    [ "Menu_Miniature.h", "_menu___miniature_8h.html", [
      [ "Menu_Miniature", "class_menu___miniature.html", "class_menu___miniature" ]
    ] ],
    [ "Menu_simple.cpp", "_menu__simple_8cpp.html", null ],
    [ "Menu_simple.h", "_menu__simple_8h.html", [
      [ "Menu_simple", "class_menu__simple.html", "class_menu__simple" ]
    ] ],
    [ "Screen.h", "_screen_8h.html", [
      [ "Screen", "class_screen.html", "class_screen" ]
    ] ],
    [ "Screens.h", "_screens_8h.html", null ]
];