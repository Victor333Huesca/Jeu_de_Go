var _goban_8h =
[
    [ "Goban", "class_goban.html", "class_goban" ],
    [ "operator<<", "_goban_8h.html#af268768f99a138526e0bf82ff4d6cc39", null ],
    [ "TGOBAN", "_goban_8h.html#a8fb0ca5d8c4020b0a59e2b27b4780c99", null ]
];